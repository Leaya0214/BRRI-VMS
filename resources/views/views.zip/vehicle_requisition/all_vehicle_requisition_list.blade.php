
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2>Vehicle Requisition List</h2>
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @elseif(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
        </div>
    </div>

    <div class="row table-responsive">
        <div class="col-md-12">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant Type</th>
                        <th>Usage Date</th>
                        <th>Requisition Date</th>
                        <th>From Time</th>
                        <th>To Time</th>
                        <th>Employee</th>
                        <th>District</th>
                        <th>Total Miles</th>
                        <th>Expense Type</th>
                        <th>Project Name</th>
                        <th>Vehicle Type</th>
                        <th>Passengers</th>
                        <th>Purpose</th>
                        <th>Note</th>
                        <th>Approval Status</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($requisitions as $requisition)
                        <tr>
                            <td>{{ $requisition->id }}</td>
                            <td>{{ $requisition->applicant_type == 'সরকারি' ? 'সরকারি' : 'বেসরকারি' }}</td>
                            <td>{{ $requisition->usage_date }}</td>
                            <td>{{ $requisition->requisition_date }}</td>
                            <td>{{ $requisition->from_time }}</td>
                            <td>{{ $requisition->to_time }}</td>
                            <td>{{ $requisition->employee->name ?? 'N/A' }}</td>
                            <td>{{ $requisition->district->name ?? 'N/A' }}</td>
                            <td>{{ $requisition->total_miles }}</td>
                            <td>{{ $requisition->expense_type }}</td>
                            <td>{{ $requisition->name_of_project }}</td>
                            <td>{{ $requisition->type->vehicle_type ?? 'N/A' }}</td>
                            <td>{{ $requisition->number_of_passenger }}</td>
                            <td>{{ $requisition->purpose }}</td>
                            <td>{{ $requisition->note }}</td>
                            <td>
                                @if($requisition->forward_status == 1)
                                    <span class="text-bold" style="color: green">Stay On Director</span>
                                @elseif($requisition->forward_status == 2)
                                    <span class="text-bold" style="color: green">Stay On DGM</span>
                                @elseif($requisition->forward_status == 3)
                                    <span class="text-bold" style="color: green">Stay On TO</span>
                                @else
                                    <span class="text-bold" style="color: green">Approved</span>
                                @endif
                                {{-- {{ $requisition->forward_status ? 'Forwarded' : 'Not Forwarded' }} --}}
                            </td>
                            <td>{{ $requisition->status ? 'Active' : 'Inactive' }}</td>
                            <td>
                                {{-- <a href="{{ route('requisitions.show', $requisition->id) }}" class="btn btn-info btn-sm">View</a>
                                <a href="{{ route('requisitions.edit', $requisition->id) }}" class="btn btn-primary btn-sm">Edit</a> --}}
                                {{-- <form action="{{ route('requisitions.destroy', $requisition->id) }}" method="POST" style="display:inline;"> --}}
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this requisition?');">Delete</button>
                                {{-- </form> --}}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="18" class="text-center">No requisitions found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                {{ $requisitions->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
