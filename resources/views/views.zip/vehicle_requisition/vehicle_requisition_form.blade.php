@extends('layouts.app')

@section('content')
    <style>
        .form-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .form-header {
            background-color: #0bab2b;
            color: #ffffff;
            padding: 6px;
            border-radius: 8px;
            text-align: center;
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .form-section {
            margin-bottom: 20px;
        }

        .form-section h5 {
            font-weight: bold;
            color: #495057;
            margin-bottom: 10px;
        }
    </style>
    <div class="container">
        <div class="form-container">
            <div class="form-header">যানবাহন ব্যবহারের অনুরোধপত্র </div>
            <form action="{{route('vehicle.requisition.store')}}" method="POST">
                @csrf
                <fieldset>
                    <legend>অনুরোধের তথ্যাবলী</legend>

                    <div class="form-section p-2">
                        {{-- <h5><u>আবেদনের প্রকারভেদ</u></h5> --}}
                        <div class="row g-3 pl-3">
                            <label for="" class="col-md-3">আবেদনের প্রকার &nbsp; :</label>
                            <div class="col-md-2 d-flex align-items-center">
                                <label for="applicantTypeGov" class="form-label me-2 mb-0">সরকারি</label>
                                <input type="radio" name="applicant_type" id="applicantTypeGov" value="সরকারি"
                                    class="form-check-input">
                            </div>
                            <div class="col-md-2 d-flex align-items-center">
                                <label for="applicantTypePrivate" class="form-label me-2 mb-0">বেসরকারি</label>
                                <input type="radio" name="applicant_type" id="applicantTypePrivate" value="বেসরকারি"
                                    class="form-check-input">
                            </div>
                        </div>
                        <div class="row g-3 pl-3 pt-3">
                            <label for="" class="col-md-2 form-label">ব্যবহারের তারিখ &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="date" name="usage_date" id="usage_date" value="" class="form-control">
                            </div>

                            <label for="" class="col-md-2 form-label">আবেদনের তারিখ &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="date" name="requisition_date" id="" value="{{ date('Y-m-d') }}"
                                    class="form-control" readonly>
                            </div>
                        </div>

                        <div class="row g-3 pl-3 pt-3">
                            <label for="" class="col-md-2 form-label">সময় থেকে &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="time" name="from_time" id="" value="" class="form-control"
                                    required>
                            </div>

                            <label for="" class="col-md-2 form-label">সময় পর্যন্ত &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="time" name="to_time" id="" value="" class="form-control"
                                     required>
                            </div>
                        </div>
                        <div class="row g-3 pl-3 pt-3">
                            <label for="" class="col-md-2 form-label">গন্তব্যস্থল জেলা&nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <select name="district_id" class="form-control" id="">
                                    <option value="">Select One</option>
                                    @foreach ($district as $v_district)
                                        <option value="{{ $v_district->id }}">{{ $v_district->name }}</option>
                                    @endforeach
                                </select>
                            </div>
{{--
                            <label for="" class="col-md-2 form-label">যাত্রার স্থান &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="text" name="from_location" id="" value="" class="form-control"
                                    required>
                            </div> --}}

                        </div>
                        <div class="row  pl-3 pt-2">
                             <label for="" class="col-md-2 form-label">গন্ধব্যস্থান&nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="text" name="to_location" id="" value="" class="form-control"
                                    required>
                            </div>

                            <label for="" class="col-md-3 form-label">অনুমানিক মোট মাইলেজ &nbsp; :</label>
                            <div class="col-md-3 d-flex ">
                                <input type="text" name="total_miles" id="" value="" class="form-control"
                                    required>
                            </div>
                        </div>
                        <div class="row  pl-3 pt-2">
                            <label for="" class="col-md-2 ">খরচের খাত &nbsp; :</label>
                            <div class="col-md-2 d-flex">
                                <label for="applicantTypeGov" class="form-label  mb-0">রাজস্ব</label>
                                <input type="radio" name="expense_type" id="type2" value="রাজস্ব"
                                    class="form-check-input">
                            </div>
                            <div class="col-md-2 d-flex">
                                <label for="applicantTypePrivate" class="form-label  mb-0">প্রকল্প</label>
                                <input type="radio" name="expense_type" id="type2" value="প্রকল্প"
                                    class="form-check-input">
                            </div>

                            <label for="" class="col-md-2 form-label">প্রকল্পের নাম &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="text" name="name_of_project" id="" value="" class="form-control"
                                    required>
                            </div>
                        </div>

                        <div class="row  pl-3 pt-2">
                            <label for="" class="col-md-2 ">যানবাহনের প্রকার &nbsp; :</label>
                            <div class="col-md-4 d-flex">
                               <select name="type_id" id="" class="form-control">
                                  <option value="">Select One</option>
                                    @foreach ($vehicle_type as $type)
                                        <option value="{{ $type->id }}">{{ $type->vehicle_type }}</option>
                                    @endforeach
                               </select>
                            </div>
                            <label for="" class="col-md-2 form-label">যাত্রী সংখ্যা &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <input type="text" name="number_of_passenger" id="" value="" class="form-control"
                                    required>
                            </div>
                        </div>

                        <div class="row  pl-3 pt-2">
                            <label for="tripPurpose" class="form-label col-md-2">ব্যবহারের উদ্দেশ্য</label>
                            <div class="col-md-4 d-flex">
                               <textarea name="purpose" class="form-control" id=""  rows="3" required></textarea>
                            </div>
                            <label for="" class="col-md-2 form-label">বিশেষ বক্তব্য (যদি থাকে) &nbsp; :</label>
                            <div class="col-md-4 d-flex ">
                                <textarea class="form-control" id="note" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="row  pl-3 pt-2">
                            <label for="tripPurpose" class="form-label col-md-2">ব্যবহারের উদ্দেশ্য</label>
                            <div class="col-md-4 d-flex">
                               <textarea name="purpose" class="form-control" id=""  rows="3" required></textarea>
                            </div>
                        </div>
                    </div>
                <!-- Submit Button -->
                <div class="text-center mb-3">
                    <button type="submit" class="btn btn-primary">অনুরোধ জমা দিন</button>
                </div>
                </fieldset>


            </form>
        </div>
    </div>
@endsection
@push('script_js')
<script>
       document.addEventListener('DOMContentLoaded', function() {
        // Initialize Flatpickr with custom format
        flatpickr("#usage_date", {
            dateFormat: "d-m-Y",  // Custom format (e.g., 11-06-2022)
            altInput: true,  // Use alternate input to show the formatted date
            altFormat: "F j, Y",  // Show full date in alternate input (e.g., November 6, 2022)
        });
    });

</script>
@endpush

